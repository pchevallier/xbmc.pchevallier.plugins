# FReplay (plugin.video.freplay)

## Introduction
FReplay is an addon for Kodi/XBMC that retrieves the replay info from different french channels.

FReplay est une extension pour le media center Kodi (ex XBMC) permettant de récupérer les informations de rediffusion de différentes chaînes et site de vidéos francophones.

## Channels — Websites

### French channels
- 6ter
- Arte
- BFM TV
- BFM Business
- C8
- Canal +
- Chérie 25
- CStar
- France 2
- France 3
- France 4
- France 5
- France Ô
- La 1ère
- Gulli
- HD1
- Histoire
- iTélé
- LCP
- M6
- NRJ12
- NT1
- TF1
- TMC
- TV Breizh
- Ushuaïa TV
- W9

### Swiss channels
- RTS
- BeCuriousTV


### Canadian channels
- Vtele

### International channels
- TV5 Monde
- France 24
- TNTV
- TV5 Monde Afrique

### Websites
- Allocine
- Canal-U
- Nanarland
- L'Équipe
- Tou.tv
- Wat.tv
- CNES
