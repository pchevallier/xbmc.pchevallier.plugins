# -*- coding: utf-8 -*-
#    Copyright (C) 2019 Dag Wieers (@dagwieers) <dag@wieers.com>

#    SPDX-License-Identifier: GPL-3.0-only
#    See LICENSES/GPL-3.0-only.md for more information.
